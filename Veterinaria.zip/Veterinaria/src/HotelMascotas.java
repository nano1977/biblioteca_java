import java.util.ArrayList;

import java.util.List;



public class HotelMascotas {

  private List<Mascota> mascotas;



  public HotelMascotas() {

    this.mascotas = new ArrayList<>();

  }



  public boolean agregarMascota(Mascota mascota) {

    for (Mascota m : mascotas) {

      if (m.getCodigo().equals(mascota.getCodigo())) {

        return false; // Ya existe

      }

    }

    mascotas.add(mascota);

    return true;

  }



  public void listarMascotas() {

    for (Mascota m : mascotas) {

      m.mostrarDatos();

      System.out.println(); // Separador

    }

  }



  public int getCantidadMascotas() {

    return mascotas.size();

  }



  public double calcularCostoTotal() {

    double total = 0;

    for (Mascota m : mascotas) {

      total += m.calcularCostoAlojamiento(m.getDiasAlojamiento());

    }

    return total;

  }

}


