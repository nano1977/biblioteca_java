public class Conejo extends Mascota {

  private String tipoDieta;



  public Conejo() {}



  public Conejo(String codigo, String nombre, double peso, int edad, int diasAlojamiento, boolean requiereSupervisionVeterinaria, String tipoDieta) {

    super(codigo, nombre, peso, edad, diasAlojamiento, requiereSupervisionVeterinaria);

    this.tipoDieta = tipoDieta;

  }



  @Override

  public void mostrarDatos() {

    System.out.println("==== CONEJO ====");

    System.out.println("CODIGO: " + codigo);

    System.out.println("NOMBRE: " + nombre);

    System.out.println("PESO: " + peso);

    System.out.println("EDAD: " + edad);

    System.out.println("DIAS DE ALOJAMIENTO: " + diasAlojamiento);

    System.out.println("REQUIERE SUPERVISION: " + requiereSupervisionVeterinaria);

    System.out.println("TIPO DIETA: " + tipoDieta);

  }



  @Override

  public double calcularCostoAlojamiento(int dias) {

    return ValorDiaAlojamiento * dias * 0.93; // 7% descuento

  }



  public String getTipoDieta() {

    return tipoDieta;

  }



  public void setTipoDieta(String tipoDieta) {

    this.tipoDieta = tipoDieta;

  }

}