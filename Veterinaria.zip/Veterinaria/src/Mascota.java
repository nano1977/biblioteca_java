public abstract class Mascota implements CostoAlojamiento {

  protected String codigo;

  protected String nombre;

  protected double peso;

  protected int edad;

  protected int diasAlojamiento;

  protected boolean requiereSupervisionVeterinaria;



  public Mascota() {}



  public Mascota(String codigo, String nombre, double peso, int edad, int diasAlojamiento, boolean requiereSupervisionVeterinaria) {

    this.codigo = codigo;

    this.nombre = nombre;

    this.peso = peso;

    this.edad = edad;

    this.diasAlojamiento = diasAlojamiento;

    this.requiereSupervisionVeterinaria = requiereSupervisionVeterinaria;

  }



  public String getCodigo() {

    return codigo;

  }



  public void setCodigo(String codigo) {

    this.codigo = codigo;

  }



  public String getNombre() {

    return nombre;

  }



  public void setNombre(String nombre) {

    this.nombre = nombre;

  }



  public double getPeso() {

    return peso;

  }



  public void setPeso(double peso) {

    this.peso = peso;

  }



  public int getEdad() {

    return edad;

  }



  public void setEdad(int edad) {

    this.edad = edad;

  }



  public int getDiasAlojamiento() {

    return diasAlojamiento;

  }



  public void setDiasAlojamiento(int diasAlojamiento) {

    this.diasAlojamiento = diasAlojamiento;

  }



  public boolean isRequiereSupervisionVeterinaria() {

    return requiereSupervisionVeterinaria;

  }



  public void setRequiereSupervisionVeterinaria(boolean requiereSupervisionVeterinaria) {

    this.requiereSupervisionVeterinaria = requiereSupervisionVeterinaria;

  }



  public abstract void mostrarDatos();
}
