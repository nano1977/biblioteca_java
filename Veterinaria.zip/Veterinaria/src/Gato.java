public class Gato extends Mascota {

  private String pedigri;



  public Gato() {}



  public Gato(String codigo, String nombre, double peso, int edad, int diasAlojamiento, boolean requiereSupervisionVeterinaria, String pedigri) {

    super(codigo, nombre, peso, edad, diasAlojamiento, requiereSupervisionVeterinaria);

    this.pedigri = pedigri;

  }



  @Override

  public void mostrarDatos() {

    System.out.println("==== GATO ====");

    System.out.println("CODIGO : " + codigo);

    System.out.println("NOMBRE : " + nombre);

    System.out.println("PESO: " + peso);

    System.out.println("EDAD : " + edad);

    System.out.println("DIAS DE ALOJAMIENTO: " + diasAlojamiento);

    System.out.println("REQUIERE SUPERVISION : " + requiereSupervisionVeterinaria);

    System.out.println("PEDIGRI: " + pedigri);

  }



  @Override

  public double calcularCostoAlojamiento(int dias) {

    double costoBase = ValorDiaAlojamiento * dias;

    costoBase *= 1.05;

    return costoBase;

  }



  public String getPedigri() {

    return pedigri;

  }



  public void setPedigri(String pedigri) {

    this.pedigri = pedigri;

  }

}

