
public interface CostoAlojamiento {
    double ValorDiaAlojamiento = 25000.0;
    double calcularCostoAlojamiento(int dia);
    
    
}
