public class Veterinaria {

  public static void main(String[] args) {

    HotelMascotas hotel = new HotelMascotas();

    hotel.agregarMascota(new Perro("P001", "Firulais", 12.5, 3, 5, true, 4));

    hotel.agregarMascota(new Perro("P002", "Rocky", 20.0, 5, 3, false, 2));

    hotel.agregarMascota(new Perro("P003", "Luna", 8.3, 2, 7, true, 5));
    
    

    hotel.agregarMascota(new Gato("G001", "Michi", 4.1, 4, 6, true, "Siamés"));

    hotel.agregarMascota(new Gato("G002", "Tom", 5.0, 6, 4, false, "Sin pedigrí"));


    hotel.agregarMascota(new Conejo("C001", "Bugs", 2.2, 1, 10, false, "Heno y zanahoria"));

    hotel.agregarMascota(new Conejo("C002", "Thumper", 1.8, 2, 8, true, "Pellets"));



   

    System.out.println("=== MASCOTAS ALOJADAS ===");

    hotel.listarMascotas();



   

    System.out.println("Total de mascotas: " + hotel.getCantidadMascotas());



    

    double costoTotal = hotel.calcularCostoTotal();

    System.out.printf("Costo total a pagar: $%,.0f\n", costoTotal);

  }

}
