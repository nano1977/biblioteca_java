public class Perro extends Mascota {

  private int vecesEjercicioDiario;



  public Perro() {}



  public Perro(String codigo, String nombre, double peso, int edad, int diasAlojamiento, boolean requiereSupervisionVeterinaria, int vecesEjercicioDiario) {

    super(codigo, nombre, peso, edad, diasAlojamiento, requiereSupervisionVeterinaria);

    this.vecesEjercicioDiario = vecesEjercicioDiario;

  }



  @Override

  public void mostrarDatos() {

    System.out.println("==== PERRO ====");

    System.out.println("CODIGO: " + codigo);

    System.out.println("NOMBRE: " + nombre);

    System.out.println("PESO: " + peso);

    System.out.println("EDAD: " + edad);

    System.out.println("DIAS ALOJAMIENTO: " + diasAlojamiento);

    System.out.println("REQUIERE SUPERVISION VETERINARIA: " + requiereSupervisionVeterinaria);

    System.out.println("NUMERO DE VECES EJERCICIO DIARIO: " + vecesEjercicioDiario);

  }



  @Override

  public double calcularCostoAlojamiento(int dias) {

    double costoBase = ValorDiaAlojamiento * dias;

    if (vecesEjercicioDiario > 3) {

      costoBase *= 1.07;

    }

    return costoBase;

  }



  public int getVecesEjercicioDiario() {

    return vecesEjercicioDiario;

  }



  public void setVecesEjercicioDiario(int vecesEjercicioDiario) {

    this.vecesEjercicioDiario = vecesEjercicioDiario;

  }

}